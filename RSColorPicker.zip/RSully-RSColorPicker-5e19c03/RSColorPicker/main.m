//
//  main.m
//  RSColorPicker
//
//  Created by Ryan Sullivan on 8/12/11.
//

#import <UIKit/UIKit.h>
#import "RSColorPickerAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass(RSColorPickerAppDelegate.class));
    }
}
