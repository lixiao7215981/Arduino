//
//  RSSelectionView.h
//  RSColorPicker
//
//  Created by Ryan Sullivan on 3/12/13.
//

#import <UIKit/UIKit.h>

@interface RSSelectionLayer : CALayer
@end
