//
//  RSColorPickerAppDelegate.h
//  RSColorPicker
//
//  Created by Ryan Sullivan on 8/12/11.
//

#import <UIKit/UIKit.h>
#import "TestColorViewController.h"

@interface RSColorPickerAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
